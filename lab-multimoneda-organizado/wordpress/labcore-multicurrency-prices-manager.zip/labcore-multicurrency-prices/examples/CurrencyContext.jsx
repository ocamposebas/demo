import { createContext, useContext, useEffect, useMemo, useState } from "react";

const CurrencyContext = createContext(null);
const SUPPORTED = ["USD", "COP", "MXN"];

export function CurrencyProvider({ children }) {
  const [currency, setCurrencyState] = useState("USD");

  useEffect(() => {
    const saved = window.localStorage.getItem("labcore_currency");
    if (SUPPORTED.includes(saved)) setCurrencyState(saved);
  }, []);

  const setCurrency = (next) => {
    if (!SUPPORTED.includes(next)) return;
    window.localStorage.setItem("labcore_currency", next);
    document.cookie = `labcore_currency=${next}; Path=/; Max-Age=31536000; SameSite=Lax`;
    setCurrencyState(next);
  };

  const value = useMemo(() => ({ currency, setCurrency }), [currency]);
  return <CurrencyContext.Provider value={value}>{children}</CurrencyContext.Provider>;
}

export function useCurrency() {
  const context = useContext(CurrencyContext);
  if (!context) throw new Error("useCurrency must be used inside CurrencyProvider");
  return context;
}
