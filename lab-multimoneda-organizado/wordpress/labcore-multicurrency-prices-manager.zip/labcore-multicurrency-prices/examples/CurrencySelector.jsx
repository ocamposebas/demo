import { useCurrency } from "./CurrencyContext.jsx";

const options = [
  { code: "USD", flag: "🇺🇸" },
  { code: "COP", flag: "🇨🇴" },
  { code: "MXN", flag: "🇲🇽" },
];

export default function CurrencySelector() {
  const { currency, setCurrency } = useCurrency();

  return (
    <div className="inline-flex rounded-xl border border-white/10 bg-slate-950 p-1">
      {options.map(({ code, flag }) => (
        <button
          key={code}
          type="button"
          onClick={() => setCurrency(code)}
          className={`rounded-lg px-3 py-2 text-xs font-bold ${
            currency === code ? "bg-cyan-300 text-slate-950" : "text-slate-400"
          }`}
        >
          {flag} {code}
        </button>
      ))}
    </div>
  );
}
