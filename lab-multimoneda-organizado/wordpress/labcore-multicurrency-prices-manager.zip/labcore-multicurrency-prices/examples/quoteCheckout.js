export async function quoteCheckout({ wordpressUrl, currency, country, items }) {
  const response = await fetch(
    `${wordpressUrl.replace(/\/$/, "")}/wp-json/labcore-multicurrency/v1/quote`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ currency, country, items }),
    },
  );

  const payload = await response.json();
  if (!response.ok) {
    throw new Error(payload?.message || "No fue posible calcular la cotización.");
  }

  return payload;
}
