# Labcore Multi-Currency Prices

Plugin de WooCommerce para administrar precios manuales en USD, COP y MXN desde un panel central.

## Panel principal

Ve a **WooCommerce → Precios Multimoneda**.

El editor muestra:

- Todos los productos simples.
- Cada producto variable como encabezado.
- Todas sus variantes debajo, una por una.
- Precio normal y precio de oferta para USD.
- Precio normal y precio de oferta para COP.
- Precio normal y precio de oferta para MXN.
- Buscador, paginación y selector de cantidad de productos por página.
- Indicador de filas modificadas y guardado conjunto.

El formulario envía los datos como JSON para evitar problemas con `max_input_vars` cuando existen muchas variantes.

## Reglas de moneda

- USD — Estados Unidos y países sin regla específica.
- COP — Colombia.
- MXN — México.

El precio USD se sincroniza con los campos nativos de precio de WooCommerce. Los precios COP y MXN se almacenan como precios manuales independientes.

## Otras funciones

- Campos adicionales dentro de la edición individual de cada producto.
- Compatible con productos simples y variaciones.
- Selector mediante shortcode: `[labcore_currency_selector]`.
- Detección Colombia → COP, México → MXN y otros países → USD.
- Guarda la moneda elegida en cookie.
- Agrega `labcore_multicurrency` a las respuestas REST de productos y variaciones.
- API propia para Astro/React.
- Endpoint de cotización que valida productos, stock, cantidades y precios en el servidor.
- Compatibilidad declarada con HPOS.

## Instalación

1. Ve a **WordPress → Plugins → Añadir plugin → Subir plugin**.
2. Sube `labcore-multicurrency-prices-manager.zip`.
3. Activa el plugin.
4. Ve a **WooCommerce → Precios Multimoneda**.
5. Escribe los precios de cada producto y variante.
6. Presiona **Guardar todos los precios**.

## API para Astro / React

```http
GET /wp-json/labcore-multicurrency/v1/product/123?currency=COP
```

```http
GET /wp-json/labcore-multicurrency/v1/prices?ids=123,456,789&currency=MXN
```

```http
POST /wp-json/labcore-multicurrency/v1/quote
Content-Type: application/json

{
  "currency": "COP",
  "country": "CO",
  "items": [
    { "productId": 123, "variationId": 456, "quantity": 2 }
  ]
}
```

La cotización devuelve precios calculados desde WordPress. El checkout no debe confiar en precios enviados directamente por el navegador.

## Nota sobre Bold

WooCommerce puede almacenar órdenes y precios en USD, COP y MXN. La moneda que realmente puede cobrarse depende de las monedas admitidas por la cuenta y la integración de la pasarela. Esta validación debe realizarse antes de firmar el pago.
