<?php
/**
 * Plugin Name: Labcore Multi-Currency Prices
 * Description: Central price manager for manual USD, COP and MXN prices across all WooCommerce products and variations, with country detection and REST support for custom frontends.
 * Version:     1.1.0
 * Author:      Labcore
 * Text Domain: labcore-multicurrency
 * Requires at least: 6.4
 * Requires PHP: 7.4
 * WC requires at least: 8.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Labcore_Multi_Currency_Prices {
	const VERSION = '1.1.0';
	const OPTION_KEY = 'labcore_mc_settings';
	const COOKIE_NAME = 'labcore_currency';
	const REST_NAMESPACE = 'labcore-multicurrency/v1';

	private static $instance = null;
	private $active_currency = null;
	private $is_syncing_usd = false;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'plugins_loaded', array( $this, 'boot' ) );
	}

	public function boot() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action( 'admin_notices', array( $this, 'woocommerce_required_notice' ) );
			return;
		}

		add_action( 'before_woocommerce_init', array( $this, 'declare_hpos_compatibility' ) );

		// Admin product fields.
		add_filter( 'woocommerce_product_data_tabs', array( $this, 'add_product_data_tab' ) );
		add_action( 'woocommerce_product_data_panels', array( $this, 'render_product_data_panel' ) );
		add_action( 'woocommerce_admin_process_product_object', array( $this, 'save_product_currency_prices' ) );
		add_action( 'woocommerce_variation_options_pricing', array( $this, 'render_variation_currency_prices' ), 20, 3 );
		add_action( 'woocommerce_save_product_variation', array( $this, 'save_variation_currency_prices' ), 20, 2 );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_assets' ) );

		// Settings.
		add_action( 'admin_menu', array( $this, 'register_settings_page' ), 99 );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_post_labcore_mc_save_matrix', array( $this, 'save_price_matrix' ) );

		// Currency and prices on the WooCommerce frontend.
		add_filter( 'woocommerce_currency', array( $this, 'filter_woocommerce_currency' ), 50 );
		add_filter( 'wc_get_price_decimals', array( $this, 'filter_price_decimals' ), 50 );
		add_filter( 'woocommerce_product_get_price', array( $this, 'filter_product_price' ), 50, 2 );
		add_filter( 'woocommerce_product_get_regular_price', array( $this, 'filter_product_regular_price' ), 50, 2 );
		add_filter( 'woocommerce_product_get_sale_price', array( $this, 'filter_product_sale_price' ), 50, 2 );
		add_filter( 'woocommerce_product_variation_get_price', array( $this, 'filter_product_price' ), 50, 2 );
		add_filter( 'woocommerce_product_variation_get_regular_price', array( $this, 'filter_product_regular_price' ), 50, 2 );
		add_filter( 'woocommerce_product_variation_get_sale_price', array( $this, 'filter_product_sale_price' ), 50, 2 );
		add_filter( 'woocommerce_variation_prices_price', array( $this, 'filter_variation_price_array' ), 50, 3 );
		add_filter( 'woocommerce_variation_prices_regular_price', array( $this, 'filter_variation_regular_price_array' ), 50, 3 );
		add_filter( 'woocommerce_variation_prices_sale_price', array( $this, 'filter_variation_sale_price_array' ), 50, 3 );
		add_action( 'woocommerce_before_calculate_totals', array( $this, 'apply_cart_currency_prices' ), 50 );
		add_action( 'woocommerce_checkout_create_order', array( $this, 'set_order_currency' ), 20, 2 );
		add_filter( 'woocommerce_get_variation_prices_hash', array( $this, 'variation_prices_hash' ), 50, 3 );

		// Selector and cookie.
		add_shortcode( 'labcore_currency_selector', array( $this, 'currency_selector_shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'frontend_assets' ) );

		// REST API for Astro / React and extension data in WooCommerce responses.
		add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );
		add_filter( 'woocommerce_rest_prepare_product_object', array( $this, 'extend_product_rest_response' ), 20, 3 );
		add_filter( 'woocommerce_rest_prepare_product_variation_object', array( $this, 'extend_product_rest_response' ), 20, 3 );
	}

	public function declare_hpos_compatibility() {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		}
	}

	public function woocommerce_required_notice() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		echo '<div class="notice notice-error"><p><strong>Labcore Multi-Currency Prices</strong> requiere WooCommerce activo.</p></div>';
	}

	public function currencies() {
		return array(
			'USD' => array(
				'label'   => 'USD — Dólar estadounidense',
				'symbol'  => '$',
				'decimals'=> 2,
				'locale'  => 'en-US',
			),
			'COP' => array(
				'label'   => 'COP — Peso colombiano',
				'symbol'  => '$',
				'decimals'=> 0,
				'locale'  => 'es-CO',
			),
			'MXN' => array(
				'label'   => 'MXN — Peso mexicano',
				'symbol'  => '$',
				'decimals'=> 2,
				'locale'  => 'es-MX',
			),
		);
	}

	private function settings() {
		$defaults = array(
			'default_currency' => 'USD',
			'auto_detect'      => 'yes',
			'enable_selector'  => 'yes',
		);
		return wp_parse_args( get_option( self::OPTION_KEY, array() ), $defaults );
	}

	private function sanitize_currency( $currency ) {
		$currency = strtoupper( sanitize_text_field( (string) $currency ) );
		return array_key_exists( $currency, $this->currencies() ) ? $currency : '';
	}

	private function currency_from_country( $country ) {
		$country = strtoupper( sanitize_text_field( (string) $country ) );
		if ( 'CO' === $country ) {
			return 'COP';
		}
		if ( 'MX' === $country ) {
			return 'MXN';
		}
		return 'USD';
	}

	public function get_active_currency() {
		if ( $this->active_currency ) {
			return $this->active_currency;
		}

		$settings = $this->settings();
		$currency = '';

		// Explicit REST/query parameter has highest priority for custom frontends.
		if ( isset( $_GET['currency'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$currency = $this->sanitize_currency( wp_unslash( $_GET['currency'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		// Optional HTTP header for server-to-server requests.
		if ( ! $currency && isset( $_SERVER['HTTP_X_LABCORE_CURRENCY'] ) ) {
			$currency = $this->sanitize_currency( wp_unslash( $_SERVER['HTTP_X_LABCORE_CURRENCY'] ) );
		}

		if ( ! $currency && isset( $_COOKIE[ self::COOKIE_NAME ] ) ) {
			$currency = $this->sanitize_currency( wp_unslash( $_COOKIE[ self::COOKIE_NAME ] ) );
		}

		// Logged-in/customer session address.
		if ( ! $currency && function_exists( 'WC' ) && WC()->customer ) {
			$country = WC()->customer->get_shipping_country();
			if ( ! $country ) {
				$country = WC()->customer->get_billing_country();
			}
			if ( $country ) {
				$currency = $this->currency_from_country( $country );
			}
		}

		// WooCommerce geolocation for first visit.
		if ( ! $currency && 'yes' === $settings['auto_detect'] && class_exists( 'WC_Geolocation' ) ) {
			$geo = WC_Geolocation::geolocate_ip();
			if ( ! empty( $geo['country'] ) ) {
				$currency = $this->currency_from_country( $geo['country'] );
			}
		}

		if ( ! $currency ) {
			$currency = $this->sanitize_currency( $settings['default_currency'] );
		}

		$this->active_currency = $currency ?: 'USD';
		return $this->active_currency;
	}

	public function filter_woocommerce_currency( $currency ) {
		if ( is_admin() && ! wp_doing_ajax() && ! $this->is_rest_request() ) {
			return $currency;
		}
		return $this->get_active_currency();
	}

	public function filter_price_decimals( $decimals ) {
		if ( is_admin() && ! wp_doing_ajax() && ! $this->is_rest_request() ) {
			return $decimals;
		}
		$currency = $this->get_active_currency();
		$config = $this->currencies();
		return isset( $config[ $currency ]['decimals'] ) ? (int) $config[ $currency ]['decimals'] : $decimals;
	}

	private function is_rest_request() {
		return defined( 'REST_REQUEST' ) && REST_REQUEST;
	}

	private function meta_key( $currency, $type ) {
		return '_labcore_mc_' . strtolower( $currency ) . '_' . $type;
	}

	private function clean_price( $raw ) {
		if ( '' === $raw || null === $raw ) {
			return '';
		}
		return wc_format_decimal( wp_unslash( $raw ) );
	}

	private function get_manual_price( $product, $currency, $type = 'price' ) {
		if ( ! $product instanceof WC_Product ) {
			return '';
		}

		$currency = $this->sanitize_currency( $currency );
		if ( ! $currency ) {
			return '';
		}

		if ( 'price' === $type ) {
			$sale = $product->get_meta( $this->meta_key( $currency, 'sale' ), true );
			if ( '' !== $sale && is_numeric( $sale ) ) {
				return (string) $sale;
			}
			return (string) $product->get_meta( $this->meta_key( $currency, 'regular' ), true );
		}

		return (string) $product->get_meta( $this->meta_key( $currency, $type ), true );
	}

	private function get_price_or_fallback( $product, $currency, $type, $original ) {
		$manual = $this->get_manual_price( $product, $currency, $type );
		if ( '' !== $manual && is_numeric( $manual ) ) {
			return $manual;
		}

		// USD remains compatible with the native WooCommerce base fields.
		if ( 'USD' === $currency ) {
			return $original;
		}

		return $original;
	}

	public function filter_product_price( $price, $product ) {
		if ( $this->should_skip_price_filters() ) {
			return $price;
		}
		return $this->get_price_or_fallback( $product, $this->get_active_currency(), 'price', $price );
	}

	public function filter_product_regular_price( $price, $product ) {
		if ( $this->should_skip_price_filters() ) {
			return $price;
		}
		return $this->get_price_or_fallback( $product, $this->get_active_currency(), 'regular', $price );
	}

	public function filter_product_sale_price( $price, $product ) {
		if ( $this->should_skip_price_filters() ) {
			return $price;
		}
		$manual = $this->get_manual_price( $product, $this->get_active_currency(), 'sale' );
		return ( '' !== $manual && is_numeric( $manual ) ) ? $manual : $price;
	}

	private function should_skip_price_filters() {
		return is_admin() && ! wp_doing_ajax() && ! $this->is_rest_request();
	}

	public function filter_variation_price_array( $price, $variation, $product ) {
		return $this->filter_product_price( $price, $variation );
	}

	public function filter_variation_regular_price_array( $price, $variation, $product ) {
		return $this->filter_product_regular_price( $price, $variation );
	}

	public function filter_variation_sale_price_array( $price, $variation, $product ) {
		return $this->filter_product_sale_price( $price, $variation );
	}

	public function variation_prices_hash( $hash, $product, $for_display ) {
		$hash['labcore_currency'] = $this->get_active_currency();
		$hash['labcore_mc_version'] = self::VERSION;
		return $hash;
	}

	public function apply_cart_currency_prices( $cart ) {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return;
		}
		if ( ! $cart instanceof WC_Cart ) {
			return;
		}

		$currency = $this->get_active_currency();
		foreach ( $cart->get_cart() as $cart_item ) {
			if ( empty( $cart_item['data'] ) || ! $cart_item['data'] instanceof WC_Product ) {
				continue;
			}
			$price = $this->get_manual_price( $cart_item['data'], $currency, 'price' );
			if ( '' !== $price && is_numeric( $price ) ) {
				$cart_item['data']->set_price( (float) $price );
			}
		}
	}

	public function set_order_currency( $order, $data ) {
		if ( $order instanceof WC_Order ) {
			$order->set_currency( $this->get_active_currency() );
			$order->update_meta_data( '_labcore_currency_source', 'labcore-multicurrency' );
		}
	}

	public function add_product_data_tab( $tabs ) {
		$tabs['labcore_multicurrency'] = array(
			'label'    => __( 'Precios por moneda', 'labcore-multicurrency' ),
			'target'   => 'labcore_multicurrency_product_data',
			'class'    => array(),
			'priority' => 65,
		);
		return $tabs;
	}

	public function render_product_data_panel() {
		global $post;
		$product = wc_get_product( $post->ID );
		?>
		<div id="labcore_multicurrency_product_data" class="panel woocommerce_options_panel hidden">
			<div class="labcore-mc-intro">
				<strong><?php esc_html_e( 'Precios manuales por país', 'labcore-multicurrency' ); ?></strong>
				<p><?php esc_html_e( 'Colombia usa COP, México usa MXN y los demás países usan USD. El precio USD también se sincroniza con el precio base de WooCommerce.', 'labcore-multicurrency' ); ?></p>
			</div>
			<?php
			foreach ( $this->currencies() as $currency => $config ) {
				$this->render_admin_price_fields( $product, $currency, $config );
			}
			?>
		</div>
		<?php
	}

	private function render_admin_price_fields( $product, $currency, $config ) {
		$regular_key = $this->meta_key( $currency, 'regular' );
		$sale_key    = $this->meta_key( $currency, 'sale' );
		?>
		<div class="labcore-mc-currency-card">
			<h4><?php echo esc_html( $config['label'] ); ?></h4>
			<?php
			woocommerce_wp_text_input(
				array(
					'id'                => $regular_key,
					'label'             => sprintf( __( 'Precio normal %s', 'labcore-multicurrency' ), $currency ),
					'value'             => $product ? $product->get_meta( $regular_key, true ) : '',
					'data_type'         => 'price',
					'desc_tip'          => true,
					'description'       => sprintf( __( 'Precio exacto que verá el cliente en %s.', 'labcore-multicurrency' ), $currency ),
					'custom_attributes' => array( 'step' => 'any', 'min' => '0' ),
				)
			);
			woocommerce_wp_text_input(
				array(
					'id'                => $sale_key,
					'label'             => sprintf( __( 'Precio de oferta %s', 'labcore-multicurrency' ), $currency ),
					'value'             => $product ? $product->get_meta( $sale_key, true ) : '',
					'data_type'         => 'price',
					'custom_attributes' => array( 'step' => 'any', 'min' => '0' ),
				)
			);
			?>
		</div>
		<?php
	}

	public function save_product_currency_prices( $product ) {
		if ( ! $product instanceof WC_Product ) {
			return;
		}

		foreach ( array_keys( $this->currencies() ) as $currency ) {
			$regular_key = $this->meta_key( $currency, 'regular' );
			$sale_key    = $this->meta_key( $currency, 'sale' );
			$regular     = isset( $_POST[ $regular_key ] ) ? $this->clean_price( $_POST[ $regular_key ] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$sale        = isset( $_POST[ $sale_key ] ) ? $this->clean_price( $_POST[ $sale_key ] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing

			$product->update_meta_data( $regular_key, $regular );
			$product->update_meta_data( $sale_key, $sale );

			if ( 'USD' === $currency && ! $this->is_syncing_usd ) {
				$this->is_syncing_usd = true;
				if ( '' !== $regular ) {
					$product->set_regular_price( $regular );
				}
				$product->set_sale_price( $sale );
				$product->set_price( '' !== $sale ? $sale : $regular );
				$this->is_syncing_usd = false;
			}
		}
	}

	public function render_variation_currency_prices( $loop, $variation_data, $variation ) {
		$variation_product = wc_get_product( $variation->ID );
		?>
		<div class="labcore-mc-variation-wrap form-row form-row-full">
			<p class="labcore-mc-variation-title"><strong><?php esc_html_e( 'Precios por moneda', 'labcore-multicurrency' ); ?></strong></p>
			<div class="labcore-mc-variation-grid">
				<?php foreach ( $this->currencies() as $currency => $config ) :
					$regular_key = $this->meta_key( $currency, 'regular' );
					$sale_key    = $this->meta_key( $currency, 'sale' );
					?>
					<div class="labcore-mc-variation-card">
						<strong><?php echo esc_html( $currency ); ?></strong>
						<?php
						woocommerce_wp_text_input(
							array(
								'id'                => $regular_key . '_' . $loop,
								'name'              => $regular_key . '[' . $loop . ']',
								'label'             => __( 'Precio normal', 'labcore-multicurrency' ),
								'value'             => $variation_product ? $variation_product->get_meta( $regular_key, true ) : '',
								'data_type'         => 'price',
								'wrapper_class'     => 'form-row form-row-full',
								'custom_attributes' => array( 'step' => 'any', 'min' => '0' ),
							)
						);
						woocommerce_wp_text_input(
							array(
								'id'                => $sale_key . '_' . $loop,
								'name'              => $sale_key . '[' . $loop . ']',
								'label'             => __( 'Oferta', 'labcore-multicurrency' ),
								'value'             => $variation_product ? $variation_product->get_meta( $sale_key, true ) : '',
								'data_type'         => 'price',
								'wrapper_class'     => 'form-row form-row-full',
								'custom_attributes' => array( 'step' => 'any', 'min' => '0' ),
							)
						);
						?>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	public function save_variation_currency_prices( $variation_id, $loop ) {
		$product = wc_get_product( $variation_id );
		if ( ! $product ) {
			return;
		}

		foreach ( array_keys( $this->currencies() ) as $currency ) {
			$regular_key = $this->meta_key( $currency, 'regular' );
			$sale_key    = $this->meta_key( $currency, 'sale' );
			$regular     = isset( $_POST[ $regular_key ][ $loop ] ) ? $this->clean_price( $_POST[ $regular_key ][ $loop ] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$sale        = isset( $_POST[ $sale_key ][ $loop ] ) ? $this->clean_price( $_POST[ $sale_key ][ $loop ] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing

			$product->update_meta_data( $regular_key, $regular );
			$product->update_meta_data( $sale_key, $sale );

			if ( 'USD' === $currency ) {
				if ( '' !== $regular ) {
					$product->set_regular_price( $regular );
				}
				$product->set_sale_price( $sale );
				$product->set_price( '' !== $sale ? $sale : $regular );
			}
		}

		$product->save();
		wc_delete_product_transients( $product->get_parent_id() );
	}

	public function admin_assets( $hook ) {
		if ( ! in_array( $hook, array( 'post.php', 'post-new.php', 'woocommerce_page_labcore-multicurrency' ), true ) ) {
			return;
		}
		$css = '
			#labcore_multicurrency_product_data{padding:16px 18px 22px;background:#f6f8fb}
			.labcore-mc-intro{padding:14px 16px;margin-bottom:14px;background:#111827;color:#fff;border-radius:10px}
			.labcore-mc-intro p{margin:5px 0 0;color:#cbd5e1}
			.labcore-mc-currency-card{padding:14px 0 8px;margin-bottom:12px;background:#fff;border:1px solid #dbe3ec;border-radius:10px}
			.labcore-mc-currency-card h4{margin:0 14px 8px;color:#0f172a}
			.labcore-mc-variation-wrap{box-sizing:border-box;padding:12px!important;margin:12px 0!important;border:1px solid #dbe3ec;border-radius:10px;background:#f8fafc}
			.labcore-mc-variation-title{margin:0 0 10px!important}
			.labcore-mc-variation-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}
			.labcore-mc-variation-card{padding:10px;background:#fff;border:1px solid #e2e8f0;border-radius:8px}
			.labcore-mc-variation-card p{padding:0!important;margin:8px 0 0!important;width:100%!important}
			.labcore-mc-variation-card label{float:none!important;width:auto!important;margin:0 0 4px!important}
			.labcore-mc-variation-card input{width:100%!important}

			.labcore-mc-manager-wrap{max-width:none;margin:20px 20px 0 2px}
			.labcore-mc-page-head{display:flex;align-items:center;justify-content:space-between;gap:24px;padding:24px 26px;margin-bottom:18px;border:1px solid #cbd5e1;border-radius:18px;background:linear-gradient(135deg,#07111f 0%,#0b1f34 55%,#062533 100%);box-shadow:0 18px 48px rgba(15,23,42,.12);color:#fff}
			.labcore-mc-page-head h1{margin:3px 0 8px;color:#fff;font-size:27px;line-height:1.2}
			.labcore-mc-page-head p{margin:0;color:#b9c8d8}
			.labcore-mc-kicker{font:700 10px/1.2 monospace!important;letter-spacing:.17em;color:#67e8f9!important}
			.labcore-mc-country-map{display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end}
			.labcore-mc-country-map span{padding:10px 13px;border:1px solid rgba(103,232,249,.18);border-radius:12px;background:rgba(255,255,255,.045);font:700 11px/1 monospace;color:#e5f9ff}
			.labcore-mc-tabs{margin-bottom:16px;border-bottom-color:#cbd5e1}
			.labcore-mc-tabs .nav-tab{border-radius:10px 10px 0 0;font-weight:700}
			.labcore-mc-toolbar{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:12px 14px;margin-bottom:12px;border:1px solid #d7e0e9;border-radius:14px;background:#fff}
			.labcore-mc-search{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
			.labcore-mc-search input[type=search]{min-width:300px;height:38px;border-color:#cbd5e1;border-radius:9px}
			.labcore-mc-search select{height:38px;border-color:#cbd5e1;border-radius:9px}
			.labcore-mc-toolbar-note{display:flex;align-items:baseline;gap:6px;color:#64748b}
			.labcore-mc-toolbar-note strong{font-size:18px;color:#0f172a}
			.labcore-mc-matrix-shell{overflow:auto;max-height:calc(100vh - 300px);border:1px solid #cbd5e1;border-radius:16px;background:#fff;box-shadow:0 12px 30px rgba(15,23,42,.06)}
			.labcore-mc-matrix{min-width:1180px;border:0!important;border-collapse:separate;border-spacing:0}
			.labcore-mc-matrix thead th{position:sticky;top:0;z-index:4;padding:10px 8px;border-color:#dce4ec;background:#f8fafc;color:#334155;text-align:center;font-size:11px;text-transform:uppercase;letter-spacing:.06em}
			.labcore-mc-matrix thead .labcore-mc-group-head th{top:0;background:#eaf1f7;color:#0f172a;font-size:12px}
			.labcore-mc-matrix thead tr:nth-child(2) th{top:39px;z-index:5}
			.labcore-mc-matrix thead .labcore-mc-product-col{left:0;z-index:7;min-width:340px;text-align:left}
			.labcore-mc-matrix td{padding:9px 8px;vertical-align:middle;border-color:#e5eaf0}
			.labcore-mc-product-cell{position:sticky;left:0;z-index:2;min-width:340px;background:#fff!important;box-shadow:1px 0 0 #e2e8f0}
			.labcore-mc-matrix .is-variation .labcore-mc-product-cell{background:#f8fbfd!important}
			.labcore-mc-parent-row td{background:#0f2133!important;color:#fff;border-color:#21384a}
			.labcore-mc-parent-row .labcore-mc-product-cell{background:#0f2133!important;z-index:3}
			.labcore-mc-product-main{display:flex;align-items:center;gap:11px;min-width:0}
			.labcore-mc-thumb{display:block;width:42px!important;height:42px!important;object-fit:cover;border:1px solid #dbe3eb;border-radius:9px;background:#f8fafc}
			.labcore-mc-product-name{display:block;max-width:270px;overflow:hidden;color:#0f172a;font-weight:700;text-overflow:ellipsis;white-space:nowrap;text-decoration:none}
			.labcore-mc-parent-row .labcore-mc-product-name{color:#fff}
			.labcore-mc-product-name:hover{color:#0891b2}
			.labcore-mc-product-meta{display:flex;align-items:center;gap:7px;margin-top:4px;color:#7b8a9a;font:600 10px/1.2 monospace}
			.labcore-mc-parent-row .labcore-mc-product-meta{color:#9fb1c2}
			.labcore-mc-badge{display:inline-flex;padding:3px 6px;border-radius:999px;background:#dff7fc;color:#0e7490;font-size:9px}
			.labcore-mc-badge.is-variation{background:#ede9fe;color:#6d28d9}
			.labcore-mc-branch{display:flex;width:42px;height:42px;align-items:center;justify-content:center;color:#7c3aed;font-size:22px}
			.labcore-mc-variable-note{padding-left:18px!important;color:#cbd5e1!important;font-style:italic}
			.labcore-mc-price-cell{min-width:132px;background:#fff}
			.labcore-mc-price-cell.currency-usd{background:#f8fbff}
			.labcore-mc-price-cell.currency-cop{background:#fbfef8}
			.labcore-mc-price-cell.currency-mxn{background:#fffaf8}
			.labcore-mc-input-wrap{display:flex;align-items:center;border:1px solid #cbd5e1;border-radius:9px;background:#fff;overflow:hidden;transition:.16s ease}
			.labcore-mc-input-wrap:focus-within{border-color:#06b6d4;box-shadow:0 0 0 3px rgba(6,182,212,.12)}
			.labcore-mc-input-wrap>span{padding:0 0 0 9px;color:#94a3b8;font-weight:700}
			.labcore-mc-price-input{width:100%;min-width:0;height:38px!important;margin:0!important;padding:0 8px!important;border:0!important;background:transparent!important;box-shadow:none!important;color:#0f172a;font-weight:700}
			.labcore-mc-price-row.is-dirty td{box-shadow:inset 0 1px 0 rgba(245,158,11,.35),inset 0 -1px 0 rgba(245,158,11,.35)}
			.labcore-mc-price-row.is-dirty .labcore-mc-product-cell:after{content:"CAMBIADO";display:inline-flex;margin-top:5px;padding:2px 6px;border-radius:999px;background:#fff7ed;color:#c2410c;font:700 8px/1.3 monospace}
			.labcore-mc-savebar{position:sticky;bottom:0;z-index:20;display:flex;align-items:center;justify-content:space-between;gap:18px;padding:13px 16px;margin-top:12px;border:1px solid #b9c8d8;border-radius:15px;background:rgba(255,255,255,.96);box-shadow:0 -8px 28px rgba(15,23,42,.10);backdrop-filter:blur(12px)}
			.labcore-mc-savebar>div{display:grid;gap:3px}.labcore-mc-savebar strong{color:#0f172a}.labcore-mc-savebar span{color:#64748b;font-size:12px}
			.labcore-mc-savebar.has-changes strong{color:#c2410c}
			.labcore-mc-settings-card{padding:22px;border:1px solid #d7e0e9;border-radius:16px;background:#fff}
			.labcore-mc-api-box{padding:18px;margin-top:20px;border:1px solid #cbd5e1;border-radius:12px;background:#f8fafc}
			.labcore-mc-empty{padding:45px!important;text-align:center;color:#64748b}
			@media(max-width:900px){.labcore-mc-variation-grid{grid-template-columns:1fr}.labcore-mc-page-head,.labcore-mc-toolbar,.labcore-mc-savebar{align-items:stretch;flex-direction:column}.labcore-mc-country-map{justify-content:flex-start}.labcore-mc-search input[type=search]{min-width:220px;width:100%}.labcore-mc-manager-wrap{margin-right:10px}}
		';
		wp_register_style( 'labcore-mc-admin', false, array(), self::VERSION );
		wp_enqueue_style( 'labcore-mc-admin' );
		wp_add_inline_style( 'labcore-mc-admin', $css );

		if ( 'woocommerce_page_labcore-multicurrency' === $hook ) {
			$js = <<<'JS'
(function(){
	var form = document.getElementById('labcore-mc-matrix-form');
	if (!form) return;
	var inputs = Array.prototype.slice.call(form.querySelectorAll('.labcore-mc-price-input'));
	var status = document.getElementById('labcore-mc-save-status');
	var savebar = form.querySelector('.labcore-mc-savebar');
	var changed = 0;

	inputs.forEach(function(input){
		input.dataset.originalValue = input.value;
		input.addEventListener('input', function(){
			var row = input.closest('[data-product-row]');
			var rowInputs = Array.prototype.slice.call(row.querySelectorAll('.labcore-mc-price-input'));
			var dirty = rowInputs.some(function(field){ return field.value !== field.dataset.originalValue; });
			row.classList.toggle('is-dirty', dirty);
			changed = form.querySelectorAll('.labcore-mc-price-row.is-dirty').length;
			if (status) status.textContent = changed ? changed + (changed === 1 ? ' fila modificada' : ' filas modificadas') : 'Sin cambios pendientes';
			if (savebar) savebar.classList.toggle('has-changes', changed > 0);
		});
	});

	form.addEventListener('submit', function(){
		var payload = {};
		inputs.forEach(function(input){
			var id = input.dataset.product;
			var currency = input.dataset.currency;
			var type = input.dataset.priceType;
			if (!payload[id]) payload[id] = {};
			if (!payload[id][currency]) payload[id][currency] = {};
			payload[id][currency][type] = input.value;
		});
		document.getElementById('labcore_prices_json').value = JSON.stringify(payload);
		var button = document.getElementById('labcore-mc-save-button');
		if (button) { button.disabled = true; button.textContent = 'Guardando precios…'; }
	});

	window.addEventListener('beforeunload', function(event){
		if (!changed || form.dataset.submitting === 'yes') return;
		event.preventDefault();
		event.returnValue = '';
	});
	form.addEventListener('submit', function(){ form.dataset.submitting = 'yes'; });
})();
JS;
			wp_register_script( 'labcore-mc-admin', '', array(), self::VERSION, true );
			wp_enqueue_script( 'labcore-mc-admin' );
			wp_add_inline_script( 'labcore-mc-admin', $js );
		}
	}

	public function register_settings_page() {
		add_submenu_page(
			'woocommerce',
			__( 'Precios Multimoneda', 'labcore-multicurrency' ),
			__( 'Precios Multimoneda', 'labcore-multicurrency' ),
			'manage_woocommerce',
			'labcore-multicurrency',
			array( $this, 'render_settings_page' )
		);
	}

	public function register_settings() {
		register_setting(
			'labcore_mc_group',
			self::OPTION_KEY,
			array( $this, 'sanitize_settings' )
		);
	}

	public function sanitize_settings( $input ) {
		return array(
			'default_currency' => $this->sanitize_currency( isset( $input['default_currency'] ) ? $input['default_currency'] : 'USD' ) ?: 'USD',
			'auto_detect'      => ! empty( $input['auto_detect'] ) ? 'yes' : 'no',
			'enable_selector'  => ! empty( $input['enable_selector'] ) ? 'yes' : 'no',
		);
	}

	public function render_settings_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'prices'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		?>
		<div class="wrap labcore-mc-manager-wrap">
			<div class="labcore-mc-page-head">
				<div>
					<p class="labcore-mc-kicker">LABCORE // PRICE CONTROL</p>
					<h1><?php esc_html_e( 'Precios multimoneda', 'labcore-multicurrency' ); ?></h1>
					<p><?php esc_html_e( 'Administra todos los precios USD, COP y MXN desde una sola pantalla, incluyendo cada variación.', 'labcore-multicurrency' ); ?></p>
				</div>
				<div class="labcore-mc-country-map">
					<span>🇺🇸 USD</span><span>🇨🇴 COP</span><span>🇲🇽 MXN</span>
				</div>
			</div>

			<nav class="nav-tab-wrapper labcore-mc-tabs">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=labcore-multicurrency&tab=prices' ) ); ?>" class="nav-tab <?php echo 'prices' === $tab ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'Editor de precios', 'labcore-multicurrency' ); ?></a>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=labcore-multicurrency&tab=settings' ) ); ?>" class="nav-tab <?php echo 'settings' === $tab ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'Configuración', 'labcore-multicurrency' ); ?></a>
			</nav>

			<?php
			if ( 'settings' === $tab ) {
				$this->render_settings_tab();
			} else {
				$this->render_price_matrix();
			}
			?>
		</div>
		<?php
	}

	private function render_settings_tab() {
		$settings = $this->settings();
		?>
		<div class="labcore-mc-settings-card">
			<form method="post" action="options.php">
				<?php settings_fields( 'labcore_mc_group' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="labcore_default_currency"><?php esc_html_e( 'Moneda predeterminada', 'labcore-multicurrency' ); ?></label></th>
						<td>
							<select id="labcore_default_currency" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[default_currency]">
								<?php foreach ( $this->currencies() as $currency => $config ) : ?>
									<option value="<?php echo esc_attr( $currency ); ?>" <?php selected( $settings['default_currency'], $currency ); ?>><?php echo esc_html( $config['label'] ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Detección automática', 'labcore-multicurrency' ); ?></th>
						<td><label><input type="checkbox" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[auto_detect]" value="1" <?php checked( $settings['auto_detect'], 'yes' ); ?>> <?php esc_html_e( 'Colombia usa COP, México usa MXN y el resto usa USD.', 'labcore-multicurrency' ); ?></label></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Selector', 'labcore-multicurrency' ); ?></th>
						<td><label><input type="checkbox" name="<?php echo esc_attr( self::OPTION_KEY ); ?>[enable_selector]" value="1" <?php checked( $settings['enable_selector'], 'yes' ); ?>> <?php esc_html_e( 'Habilitar el shortcode [labcore_currency_selector]', 'labcore-multicurrency' ); ?></label></td>
					</tr>
				</table>
				<?php submit_button( __( 'Guardar configuración', 'labcore-multicurrency' ) ); ?>
			</form>

			<div class="labcore-mc-api-box">
				<h2><?php esc_html_e( 'Conexión con Astro / React', 'labcore-multicurrency' ); ?></h2>
				<p><code>GET <?php echo esc_html( rest_url( self::REST_NAMESPACE . '/product/123?currency=COP' ) ); ?></code></p>
				<p><code>GET <?php echo esc_html( rest_url( self::REST_NAMESPACE . '/prices?ids=123,456&currency=MXN' ) ); ?></code></p>
				<p><?php esc_html_e( 'También puedes enviar X-Labcore-Currency: USD, COP o MXN.', 'labcore-multicurrency' ); ?></p>
			</div>
		</div>
		<?php
	}

	private function render_price_matrix() {
		$paged    = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$per_page = isset( $_GET['per_page'] ) ? absint( $_GET['per_page'] ) : 25; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$per_page = in_array( $per_page, array( 10, 25, 50, 100 ), true ) ? $per_page : 25;
		$search   = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$args = array(
			'post_type'      => 'product',
			'post_status'    => array( 'publish', 'draft', 'private', 'pending' ),
			'posts_per_page' => $per_page,
			'paged'          => $paged,
			'orderby'        => 'title',
			'order'          => 'ASC',
		);
		if ( $search ) {
			$args['s'] = $search;
		}
		$query = new WP_Query( $args );

		if ( isset( $_GET['labcore_saved'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$count = absint( $_GET['labcore_saved'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			echo '<div class="notice notice-success is-dismissible"><p><strong>' . esc_html( sprintf( __( '%d filas guardadas correctamente.', 'labcore-multicurrency' ), $count ) ) . '</strong></p></div>';
		}
		?>
		<div class="labcore-mc-toolbar">
			<form method="get" class="labcore-mc-search">
				<input type="hidden" name="page" value="labcore-multicurrency">
				<input type="hidden" name="tab" value="prices">
				<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Buscar producto por nombre…', 'labcore-multicurrency' ); ?>">
				<select name="per_page">
					<?php foreach ( array( 10, 25, 50, 100 ) as $size ) : ?>
						<option value="<?php echo esc_attr( $size ); ?>" <?php selected( $per_page, $size ); ?>><?php echo esc_html( sprintf( __( '%d productos', 'labcore-multicurrency' ), $size ) ); ?></option>
					<?php endforeach; ?>
				</select>
				<button class="button button-secondary"><?php esc_html_e( 'Filtrar', 'labcore-multicurrency' ); ?></button>
			</form>
			<div class="labcore-mc-toolbar-note">
				<strong><?php echo esc_html( number_format_i18n( $query->found_posts ) ); ?></strong>
				<span><?php esc_html_e( 'productos encontrados', 'labcore-multicurrency' ); ?></span>
			</div>
		</div>

		<form id="labcore-mc-matrix-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="labcore_mc_save_matrix">
			<input type="hidden" name="labcore_prices_json" id="labcore_prices_json" value="">
			<input type="hidden" name="redirect_url" value="<?php echo esc_attr( $this->current_matrix_url( $paged, $per_page, $search ) ); ?>">
			<?php wp_nonce_field( 'labcore_mc_save_matrix', 'labcore_mc_nonce' ); ?>

			<div class="labcore-mc-matrix-shell">
				<table class="widefat striped labcore-mc-matrix">
					<thead>
						<tr class="labcore-mc-group-head">
							<th rowspan="2" class="labcore-mc-product-col"><?php esc_html_e( 'Producto / variante', 'labcore-multicurrency' ); ?></th>
							<th colspan="2" class="currency-usd">🇺🇸 USD</th>
							<th colspan="2" class="currency-cop">🇨🇴 COP</th>
							<th colspan="2" class="currency-mxn">🇲🇽 MXN</th>
						</tr>
						<tr>
							<?php foreach ( array_keys( $this->currencies() ) as $currency ) : ?>
								<th><?php esc_html_e( 'Normal', 'labcore-multicurrency' ); ?></th>
								<th><?php esc_html_e( 'Oferta', 'labcore-multicurrency' ); ?></th>
							<?php endforeach; ?>
						</tr>
					</thead>
					<tbody>
						<?php
						if ( $query->have_posts() ) {
							while ( $query->have_posts() ) {
								$query->the_post();
								$product = wc_get_product( get_the_ID() );
								if ( ! $product ) {
									continue;
								}
								if ( $product->is_type( 'variable' ) ) {
									$this->render_matrix_parent_row( $product );
									foreach ( $product->get_children() as $variation_id ) {
										$variation = wc_get_product( $variation_id );
										if ( $variation && $variation->exists() ) {
											$this->render_matrix_price_row( $variation, true );
										}
									}
								} else {
									$this->render_matrix_price_row( $product, false );
								}
							}
						} else {
							echo '<tr><td colspan="7" class="labcore-mc-empty">' . esc_html__( 'No se encontraron productos.', 'labcore-multicurrency' ) . '</td></tr>';
						}
						wp_reset_postdata();
						?>
					</tbody>
				</table>
			</div>

			<div class="labcore-mc-savebar">
				<div>
					<strong id="labcore-mc-save-status"><?php esc_html_e( 'Sin cambios pendientes', 'labcore-multicurrency' ); ?></strong>
					<span><?php esc_html_e( 'Se guardarán todos los campos visibles de esta página.', 'labcore-multicurrency' ); ?></span>
				</div>
				<button type="submit" class="button button-primary button-hero" id="labcore-mc-save-button"><?php esc_html_e( 'Guardar todos los precios', 'labcore-multicurrency' ); ?></button>
			</div>
		</form>

		<?php
		if ( $query->max_num_pages > 1 ) {
			$base = add_query_arg(
				array(
					'page'     => 'labcore-multicurrency',
					'tab'      => 'prices',
					'per_page' => $per_page,
					's'        => $search,
					'paged'    => '%#%',
				),
				admin_url( 'admin.php' )
			);
			echo '<div class="tablenav"><div class="tablenav-pages">' . wp_kses_post(
				paginate_links(
					array(
						'base'      => $base,
						'format'    => '',
						'current'   => $paged,
						'total'     => $query->max_num_pages,
						'prev_text' => '‹',
						'next_text' => '›',
					)
				)
			) . '</div></div>';
		}
	}

	private function render_matrix_parent_row( $product ) {
		$edit_url = get_edit_post_link( $product->get_id() );
		?>
		<tr class="labcore-mc-parent-row">
			<td class="labcore-mc-product-cell">
				<div class="labcore-mc-product-main">
					<?php echo wp_kses_post( $product->get_image( 'woocommerce_thumbnail', array( 'class' => 'labcore-mc-thumb' ) ) ); ?>
					<div>
						<a href="<?php echo esc_url( $edit_url ); ?>" class="labcore-mc-product-name"><?php echo esc_html( $product->get_name() ); ?></a>
						<div class="labcore-mc-product-meta"><span>#<?php echo esc_html( $product->get_id() ); ?></span><span><?php echo esc_html( $product->get_sku() ?: __( 'Sin SKU', 'labcore-multicurrency' ) ); ?></span><span class="labcore-mc-badge"><?php esc_html_e( 'Producto variable', 'labcore-multicurrency' ); ?></span></div>
					</div>
				</div>
			</td>
			<td colspan="6" class="labcore-mc-variable-note"><?php esc_html_e( 'Los precios se editan individualmente en las variantes que aparecen debajo.', 'labcore-multicurrency' ); ?></td>
		</tr>
		<?php
	}

	private function render_matrix_price_row( $product, $is_variation ) {
		$edit_url = $is_variation ? get_edit_post_link( $product->get_parent_id() ) : get_edit_post_link( $product->get_id() );
		$attributes = $is_variation && $product instanceof WC_Product_Variation ? wc_get_formatted_variation( $product, true, false, true ) : '';
		?>
		<tr class="labcore-mc-price-row <?php echo $is_variation ? 'is-variation' : ''; ?>" data-product-row="<?php echo esc_attr( $product->get_id() ); ?>">
			<td class="labcore-mc-product-cell">
				<div class="labcore-mc-product-main">
					<?php if ( ! $is_variation ) : ?>
						<?php echo wp_kses_post( $product->get_image( 'woocommerce_thumbnail', array( 'class' => 'labcore-mc-thumb' ) ) ); ?>
					<?php else : ?>
						<span class="labcore-mc-branch">↳</span>
					<?php endif; ?>
					<div>
						<a href="<?php echo esc_url( $edit_url ); ?>" class="labcore-mc-product-name"><?php echo esc_html( $is_variation ? ( $attributes ?: $product->get_name() ) : $product->get_name() ); ?></a>
						<div class="labcore-mc-product-meta"><span>#<?php echo esc_html( $product->get_id() ); ?></span><span><?php echo esc_html( $product->get_sku() ?: __( 'Sin SKU', 'labcore-multicurrency' ) ); ?></span><?php if ( $is_variation ) : ?><span class="labcore-mc-badge is-variation"><?php esc_html_e( 'Variante', 'labcore-multicurrency' ); ?></span><?php endif; ?></div>
					</div>
				</div>
			</td>
			<?php foreach ( array_keys( $this->currencies() ) as $currency ) : ?>
				<?php foreach ( array( 'regular', 'sale' ) as $type ) :
					$key   = $this->meta_key( $currency, $type );
					$value = $product->get_meta( $key, true );
					if ( 'USD' === $currency && '' === $value ) {
						$value = 'regular' === $type ? $product->get_regular_price( 'edit' ) : $product->get_sale_price( 'edit' );
					}
					?>
					<td class="labcore-mc-price-cell currency-<?php echo esc_attr( strtolower( $currency ) ); ?>">
						<div class="labcore-mc-input-wrap">
							<span>$</span>
							<input
								type="number"
								step="any"
								min="0"
								inputmode="decimal"
								class="labcore-mc-price-input"
								value="<?php echo esc_attr( $value ); ?>"
								data-product="<?php echo esc_attr( $product->get_id() ); ?>"
								data-currency="<?php echo esc_attr( $currency ); ?>"
								data-price-type="<?php echo esc_attr( $type ); ?>"
								aria-label="<?php echo esc_attr( $currency . ' ' . $type . ' ' . $product->get_name() ); ?>"
							>
						</div>
					</td>
				<?php endforeach; ?>
			<?php endforeach; ?>
		</tr>
		<?php
	}

	private function current_matrix_url( $paged, $per_page, $search ) {
		return add_query_arg(
			array(
				'page'     => 'labcore-multicurrency',
				'tab'      => 'prices',
				'paged'    => $paged,
				'per_page' => $per_page,
				's'        => $search,
			),
			admin_url( 'admin.php' )
		);
	}

	public function save_price_matrix() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'No tienes permisos para modificar precios.', 'labcore-multicurrency' ) );
		}
		check_admin_referer( 'labcore_mc_save_matrix', 'labcore_mc_nonce' );

		$json = isset( $_POST['labcore_prices_json'] ) ? wp_unslash( $_POST['labcore_prices_json'] ) : '';
		$data = json_decode( $json, true );
		if ( ! is_array( $data ) ) {
			$data = array();
		}

		$saved = 0;
		$parents_to_clear = array();
		foreach ( $data as $product_id => $price_data ) {
			$product = wc_get_product( absint( $product_id ) );
			if ( ! $product || $product->is_type( 'variable' ) ) {
				continue;
			}

			foreach ( array_keys( $this->currencies() ) as $currency ) {
				$currency_data = isset( $price_data[ $currency ] ) && is_array( $price_data[ $currency ] ) ? $price_data[ $currency ] : array();
				$regular = array_key_exists( 'regular', $currency_data ) ? $this->clean_price( $currency_data['regular'] ) : '';
				$sale    = array_key_exists( 'sale', $currency_data ) ? $this->clean_price( $currency_data['sale'] ) : '';
				$product->update_meta_data( $this->meta_key( $currency, 'regular' ), $regular );
				$product->update_meta_data( $this->meta_key( $currency, 'sale' ), $sale );

				if ( 'USD' === $currency ) {
					$product->set_regular_price( $regular );
					$product->set_sale_price( $sale );
					$product->set_price( '' !== $sale ? $sale : $regular );
				}
			}

			$product->save();
			$saved++;
			if ( $product->get_parent_id() ) {
				$parents_to_clear[] = $product->get_parent_id();
			}
			wc_delete_product_transients( $product->get_id() );
		}

		foreach ( array_unique( $parents_to_clear ) as $parent_id ) {
			WC_Product_Variable::sync( $parent_id );
			wc_delete_product_transients( $parent_id );
		}

		$redirect = isset( $_POST['redirect_url'] ) ? esc_url_raw( wp_unslash( $_POST['redirect_url'] ) ) : admin_url( 'admin.php?page=labcore-multicurrency&tab=prices' );
		$redirect = wp_validate_redirect( $redirect, admin_url( 'admin.php?page=labcore-multicurrency&tab=prices' ) );
		wp_safe_redirect( add_query_arg( 'labcore_saved', $saved, $redirect ) );
		exit;
	}

	public function currency_selector_shortcode() {
		$settings = $this->settings();
		if ( 'yes' !== $settings['enable_selector'] ) {
			return '';
		}
		$active = $this->get_active_currency();
		ob_start();
		?>
		<div class="labcore-mc-selector" data-labcore-currency-selector>
			<?php foreach ( array( 'USD' => '🇺🇸', 'COP' => '🇨🇴', 'MXN' => '🇲🇽' ) as $currency => $flag ) : ?>
				<button type="button" data-currency="<?php echo esc_attr( $currency ); ?>" class="<?php echo $active === $currency ? 'is-active' : ''; ?>"><?php echo esc_html( $flag . ' ' . $currency ); ?></button>
			<?php endforeach; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	public function frontend_assets() {
		$settings = $this->settings();
		if ( 'yes' !== $settings['enable_selector'] ) {
			return;
		}
		$css = '.labcore-mc-selector{display:inline-flex;gap:6px;padding:6px;border:1px solid rgba(255,255,255,.12);border-radius:14px;background:#071224}.labcore-mc-selector button{border:0;border-radius:10px;padding:8px 10px;background:transparent;color:#94a3b8;font:700 11px/1 monospace;cursor:pointer}.labcore-mc-selector button.is-active{background:#22d3ee;color:#02111c}';
		$js = "document.addEventListener('click',function(e){var b=e.target.closest('[data-labcore-currency-selector] [data-currency]');if(!b)return;var c=b.getAttribute('data-currency');document.cookie='" . self::COOKIE_NAME . "='+c+';path=/;max-age=31536000;SameSite=Lax';var u=new URL(window.location.href);u.searchParams.set('currency',c);window.location.href=u.toString();});";
		wp_register_style( 'labcore-mc-front', false, array(), self::VERSION );
		wp_enqueue_style( 'labcore-mc-front' );
		wp_add_inline_style( 'labcore-mc-front', $css );
		wp_register_script( 'labcore-mc-front', '', array(), self::VERSION, true );
		wp_enqueue_script( 'labcore-mc-front' );
		wp_add_inline_script( 'labcore-mc-front', $js );
	}

	public function register_rest_routes() {
		register_rest_route(
			self::REST_NAMESPACE,
			'/currencies',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'rest_currencies' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/product/(?P<id>\d+)',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'rest_product_price' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'id'       => array( 'required' => true, 'validate_callback' => 'is_numeric' ),
					'currency' => array( 'required' => false, 'sanitize_callback' => 'sanitize_text_field' ),
				),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/quote',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'rest_quote' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'currency' => array( 'required' => false, 'sanitize_callback' => 'sanitize_text_field' ),
					'country'  => array( 'required' => false, 'sanitize_callback' => 'sanitize_text_field' ),
					'items'    => array( 'required' => true, 'type' => 'array' ),
				),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/prices',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'rest_bulk_prices' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'ids'      => array( 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ),
					'currency' => array( 'required' => false, 'sanitize_callback' => 'sanitize_text_field' ),
				),
			)
		);
	}

	public function rest_currencies() {
		return rest_ensure_response(
			array(
				'active'     => $this->get_active_currency(),
				'currencies' => $this->currencies(),
				'country_map'=> array( 'CO' => 'COP', 'MX' => 'MXN', '*' => 'USD' ),
			)
		);
	}

	public function rest_product_price( WP_REST_Request $request ) {
		$product = wc_get_product( absint( $request['id'] ) );
		if ( ! $product ) {
			return new WP_Error( 'labcore_product_not_found', __( 'Producto no encontrado.', 'labcore-multicurrency' ), array( 'status' => 404 ) );
		}
		$currency = $this->sanitize_currency( $request->get_param( 'currency' ) ) ?: $this->get_active_currency();
		return rest_ensure_response( $this->product_price_payload( $product, $currency ) );
	}

	public function rest_quote( WP_REST_Request $request ) {
		$currency = $this->sanitize_currency( $request->get_param( 'currency' ) );
		if ( ! $currency && $request->get_param( 'country' ) ) {
			$currency = $this->currency_from_country( $request->get_param( 'country' ) );
		}
		$currency = $currency ?: $this->get_active_currency();
		$items = $request->get_param( 'items' );
		if ( ! is_array( $items ) || empty( $items ) ) {
			return new WP_Error( 'labcore_empty_quote', __( 'Debes enviar al menos un producto.', 'labcore-multicurrency' ), array( 'status' => 400 ) );
		}
		if ( count( $items ) > 100 ) {
			return new WP_Error( 'labcore_quote_too_large', __( 'La cotización supera el máximo de 100 líneas.', 'labcore-multicurrency' ), array( 'status' => 400 ) );
		}

		$lines = array();
		$subtotal = 0.0;
		foreach ( $items as $index => $item ) {
			$product_id   = isset( $item['productId'] ) ? absint( $item['productId'] ) : 0;
			$variation_id = isset( $item['variationId'] ) ? absint( $item['variationId'] ) : 0;
			$quantity     = isset( $item['quantity'] ) ? max( 1, absint( $item['quantity'] ) ) : 1;
			$lookup_id    = $variation_id ?: $product_id;
			$product      = wc_get_product( $lookup_id );

			if ( ! $product || ! $product->is_purchasable() ) {
				return new WP_Error(
					'labcore_quote_product_invalid',
					sprintf( __( 'El producto de la línea %d no está disponible.', 'labcore-multicurrency' ), $index + 1 ),
					array( 'status' => 400, 'line' => $index )
				);
			}
			if ( $product->managing_stock() && ! $product->has_enough_stock( $quantity ) ) {
				return new WP_Error(
					'labcore_quote_insufficient_stock',
					sprintf( __( 'No hay inventario suficiente para %s.', 'labcore-multicurrency' ), $product->get_name() ),
					array( 'status' => 409, 'line' => $index )
				);
			}

			$unit_price = $this->get_product_price_for_currency( $product, $currency, 'price' );
			if ( null === $unit_price ) {
				return new WP_Error(
					'labcore_quote_price_missing',
					sprintf( __( 'Falta el precio %1$s para %2$s.', 'labcore-multicurrency' ), $currency, $product->get_name() ),
					array( 'status' => 422, 'line' => $index, 'product_id' => $lookup_id )
				);
			}

			$decimals = (int) $this->currencies()[ $currency ]['decimals'];
			$line_total = round( $unit_price * $quantity, $decimals );
			$subtotal += $line_total;
			$lines[] = array(
				'product_id'   => $product_id,
				'variation_id' => $variation_id,
				'lookup_id'    => $lookup_id,
				'name'         => $product->get_name(),
				'quantity'     => $quantity,
				'unit_price'   => $unit_price,
				'line_total'   => $line_total,
			);
		}

		return rest_ensure_response(
			array(
				'currency'  => $currency,
				'lines'     => $lines,
				'subtotal'  => round( $subtotal, (int) $this->currencies()[ $currency ]['decimals'] ),
				'formatted' => $this->format_price_value( $subtotal, $currency ),
			)
		);
	}

	public function rest_bulk_prices( WP_REST_Request $request ) {
		$ids = array_filter( array_map( 'absint', explode( ',', (string) $request->get_param( 'ids' ) ) ) );
		$ids = array_slice( array_unique( $ids ), 0, 100 );
		$currency = $this->sanitize_currency( $request->get_param( 'currency' ) ) ?: $this->get_active_currency();
		$items = array();
		foreach ( $ids as $id ) {
			$product = wc_get_product( $id );
			if ( $product ) {
				$items[] = $this->product_price_payload( $product, $currency );
			}
		}
		return rest_ensure_response( array( 'currency' => $currency, 'items' => $items ) );
	}

	public function get_product_price_for_currency( $product_or_id, $currency, $type = 'price' ) {
		$product = $product_or_id instanceof WC_Product ? $product_or_id : wc_get_product( absint( $product_or_id ) );
		if ( ! $product ) {
			return null;
		}
		$currency = $this->sanitize_currency( $currency ) ?: 'USD';
		$value = $this->get_manual_price( $product, $currency, $type );
		if ( '' === $value || ! is_numeric( $value ) ) {
			return null;
		}
		return (float) $value;
	}

	private function format_price_value( $value, $currency ) {
		$config = $this->currencies();
		$decimals = isset( $config[ $currency ]['decimals'] ) ? (int) $config[ $currency ]['decimals'] : 2;
		return html_entity_decode(
			wp_strip_all_tags(
				wc_price(
					$value,
					array(
						'currency' => $currency,
						'decimals' => $decimals,
					)
				)
			)
		);
	}

	private function product_price_payload( $product, $currency ) {
		if ( $product->is_type( 'variable' ) ) {
			$all = array();
			foreach ( array_keys( $this->currencies() ) as $code ) {
				$regular_values = array();
				$sale_values    = array();
				$current_values = array();

				foreach ( $product->get_children() as $variation_id ) {
					$variation = wc_get_product( $variation_id );
					if ( ! $variation || ! $variation->exists() ) {
						continue;
					}
					$regular = $this->get_manual_price( $variation, $code, 'regular' );
					$sale    = $this->get_manual_price( $variation, $code, 'sale' );
					$current = ( '' !== $sale && is_numeric( $sale ) ) ? $sale : $regular;
					if ( '' !== $regular && is_numeric( $regular ) ) {
						$regular_values[] = (float) $regular;
					}
					if ( '' !== $sale && is_numeric( $sale ) ) {
						$sale_values[] = (float) $sale;
					}
					if ( '' !== $current && is_numeric( $current ) ) {
						$current_values[] = (float) $current;
					}
				}

				$all[ $code ] = array(
					'regular'    => $regular_values ? min( $regular_values ) : null,
					'regular_max'=> $regular_values ? max( $regular_values ) : null,
					'sale'       => $sale_values ? min( $sale_values ) : null,
					'sale_max'   => $sale_values ? max( $sale_values ) : null,
					'price'      => $current_values ? min( $current_values ) : null,
					'price_max'  => $current_values ? max( $current_values ) : null,
				);
			}

			$selected = isset( $all[ $currency ] ) ? $all[ $currency ] : array();
			$min_price = isset( $selected['price'] ) ? $selected['price'] : null;
			$max_price = isset( $selected['price_max'] ) ? $selected['price_max'] : null;
			$formatted = null;
			if ( null !== $min_price ) {
				$formatted = ( null !== $max_price && (float) $max_price !== (float) $min_price )
					? $this->format_price_value( $min_price, $currency ) . ' – ' . $this->format_price_value( $max_price, $currency )
					: $this->format_price_value( $min_price, $currency );
			}

			return array(
				'id'            => $product->get_id(),
				'parent_id'     => 0,
				'type'          => $product->get_type(),
				'name'          => $product->get_name(),
				'currency'      => $currency,
				'regular_price' => isset( $selected['regular'] ) ? $selected['regular'] : null,
				'regular_max'   => isset( $selected['regular_max'] ) ? $selected['regular_max'] : null,
				'sale_price'    => isset( $selected['sale'] ) ? $selected['sale'] : null,
				'sale_max'      => isset( $selected['sale_max'] ) ? $selected['sale_max'] : null,
				'price'         => $min_price,
				'max_price'     => $max_price,
				'is_range'      => null !== $min_price && null !== $max_price && (float) $min_price !== (float) $max_price,
				'formatted'     => $formatted,
				'all_prices'    => $all,
			);
		}

		$regular = $this->get_manual_price( $product, $currency, 'regular' );
		$sale    = $this->get_manual_price( $product, $currency, 'sale' );
		$current = ( '' !== $sale && is_numeric( $sale ) ) ? $sale : $regular;

		$all = array();
		foreach ( array_keys( $this->currencies() ) as $code ) {
			$r = $this->get_manual_price( $product, $code, 'regular' );
			$s = $this->get_manual_price( $product, $code, 'sale' );
			$all[ $code ] = array(
				'regular' => '' === $r ? null : (float) $r,
				'sale'    => '' === $s ? null : (float) $s,
				'price'   => '' === $s ? ( '' === $r ? null : (float) $r ) : (float) $s,
			);
		}

		return array(
			'id'            => $product->get_id(),
			'parent_id'     => $product->get_parent_id(),
			'type'          => $product->get_type(),
			'name'          => $product->get_name(),
			'currency'      => $currency,
			'regular_price' => '' === $regular ? null : (float) $regular,
			'sale_price'    => '' === $sale ? null : (float) $sale,
			'price'         => '' === $current ? null : (float) $current,
			'max_price'     => '' === $current ? null : (float) $current,
			'is_range'      => false,
			'formatted'     => '' === $current ? null : $this->format_price_value( $current, $currency ),
			'all_prices'    => $all,
		);
	}

	public function extend_product_rest_response( $response, $object, $request ) {
		if ( ! $response instanceof WP_REST_Response || ! $object instanceof WC_Product ) {
			return $response;
		}
		$currency = $this->sanitize_currency( $request->get_param( 'currency' ) ) ?: $this->get_active_currency();
		$data = $response->get_data();
		$data['labcore_multicurrency'] = $this->product_price_payload( $object, $currency );
		$response->set_data( $data );
		return $response;
	}
}

/**
 * Public helper for custom checkout/server integrations.
 *
 * @param int|WC_Product $product_or_id Product or variation.
 * @param string         $currency      USD, COP or MXN.
 * @param string         $type          price, regular or sale.
 * @return float|null
 */
function labcore_mc_get_price( $product_or_id, $currency = 'USD', $type = 'price' ) {
	return Labcore_Multi_Currency_Prices::instance()->get_product_price_for_currency( $product_or_id, $currency, $type );
}

Labcore_Multi_Currency_Prices::instance();
